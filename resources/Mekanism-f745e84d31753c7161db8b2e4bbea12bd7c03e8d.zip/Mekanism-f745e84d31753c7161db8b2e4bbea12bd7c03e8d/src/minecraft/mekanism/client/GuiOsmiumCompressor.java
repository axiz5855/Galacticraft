package mekanism.client;

import mekanism.common.TileEntityAdvancedElectricMachine;
import net.minecraft.entity.player.InventoryPlayer;

public class GuiOsmiumCompressor extends GuiAdvancedElectricMachine
{
	public GuiOsmiumCompressor(InventoryPlayer inventory, TileEntityAdvancedElectricMachine tentity)
	{
		super(inventory, tentity);
	}
}
