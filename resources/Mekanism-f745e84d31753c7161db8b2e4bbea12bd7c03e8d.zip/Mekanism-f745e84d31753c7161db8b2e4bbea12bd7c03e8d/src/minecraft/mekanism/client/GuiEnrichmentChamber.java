package mekanism.client;

import mekanism.common.TileEntityElectricMachine;
import net.minecraft.entity.player.InventoryPlayer;

public class GuiEnrichmentChamber extends GuiElectricMachine
{
	public GuiEnrichmentChamber(InventoryPlayer inventory, TileEntityElectricMachine tentity)
	{
		super(inventory, tentity);
	}
}
