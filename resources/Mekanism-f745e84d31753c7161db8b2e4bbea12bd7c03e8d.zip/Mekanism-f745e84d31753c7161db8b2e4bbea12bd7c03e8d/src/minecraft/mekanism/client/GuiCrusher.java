package mekanism.client;

import mekanism.common.TileEntityElectricMachine;
import net.minecraft.entity.player.InventoryPlayer;

public class GuiCrusher extends GuiElectricMachine
{
	public GuiCrusher(InventoryPlayer inventory, TileEntityElectricMachine tentity)
	{
		super(inventory, tentity);
	}
}
