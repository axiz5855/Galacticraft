package mekanism.client;

import mekanism.common.TileEntityAdvancedElectricMachine;
import net.minecraft.entity.player.InventoryPlayer;

public class GuiCombiner extends GuiAdvancedElectricMachine
{
	public GuiCombiner(InventoryPlayer inventory, TileEntityAdvancedElectricMachine tentity)
	{
		super(inventory, tentity);
	}
}
