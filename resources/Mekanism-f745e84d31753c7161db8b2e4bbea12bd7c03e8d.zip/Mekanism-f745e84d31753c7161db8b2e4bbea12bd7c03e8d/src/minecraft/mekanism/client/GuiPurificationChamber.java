package mekanism.client;

import mekanism.common.TileEntityAdvancedElectricMachine;
import net.minecraft.entity.player.InventoryPlayer;

public class GuiPurificationChamber extends GuiAdvancedElectricMachine
{
	public GuiPurificationChamber(InventoryPlayer inventory, TileEntityAdvancedElectricMachine tentity)
	{
		super(inventory, tentity);
	}
}
