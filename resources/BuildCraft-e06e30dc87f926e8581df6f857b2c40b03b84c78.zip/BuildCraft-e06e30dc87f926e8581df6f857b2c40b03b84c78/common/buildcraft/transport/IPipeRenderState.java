package buildcraft.transport;

public interface IPipeRenderState {
	public PipeRenderState getRenderState();
}
