package buildcraft.transport;

public class TileDummyGenericPipe2 extends TileGenericPipe {

}
