package buildcraft.api.filler;

public class FillerManager {

	public static IFillerRegistry registry;

}
