package buildcraft.core.blueprints;

import buildcraft.api.blueprints.BptSlotInfo;

public class BptActionBuild extends BptSlotInfo {

}
