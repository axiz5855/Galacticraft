package buildcraft.core;

public interface IDropControlInventory {

	public boolean doDrop();

}
