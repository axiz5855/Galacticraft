## Universal Electricity

### Brief
Universal Electricity is a modular electricity API for modders to create to add electricity to Minecraft. The mod alone does not add many things to the game. It requires addons in order to work. Universal Electricity is basically a structure that integrates a universal electricity system in which all mods can use.